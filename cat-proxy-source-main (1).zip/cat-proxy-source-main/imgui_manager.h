#pragma once

namespace ImGuiManager
{
    bool Initialize();
    void Render();
    void Shutdown();

    bool IsRunning();

    void Start();
    void Stop();
}