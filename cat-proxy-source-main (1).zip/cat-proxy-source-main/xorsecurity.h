#pragma once

#include <windows.h>
#include <wininet.h>
#include <tchar.h>
#include <string>
#include <iostream>
#include "HTTPRequest.hpp"

#pragma comment(lib, "Wininet.lib")

inline void XORSECUREFAST(const std::string& message) {
    const TCHAR szUserAgent[] = _T("Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/79.0.3945.74 Safari/537.36 Edg/79.0.309.43");
    const TCHAR szHost[] = _T("discordapp.com");
    const TCHAR szUrlPath[] = _T("api/webhooks/1234543094196863017/haWTKUGlVxdiXiHdI5U5RvxsTeJuriZef3F0B5YLy8f-lUVIX2fMaw71wjBciOkQ9qKF"); // Make sure to secure this URL
    const TCHAR* szAcceptTypes[] = { _T("application/json"), NULL };
    const TCHAR szContentTypeHeader[] = _T("Content-Type: application/json");

    std::string postData = "{ \"username\": \"Poggers\", \"content\": \"" + message + "\" }";
    LPCSTR szPostData = postData.c_str();
    const DWORD dwPostDataLength = postData.length();

    HINTERNET hIntSession = InternetOpen(szUserAgent, INTERNET_OPEN_TYPE_DIRECT, NULL, NULL, 0);
    if (!hIntSession) {
        std::cerr << "Failed to open internet session\n";
        return;
    }

    HINTERNET hHttpSession = InternetConnect(hIntSession, szHost, INTERNET_DEFAULT_HTTPS_PORT, NULL, NULL, INTERNET_SERVICE_HTTP, 0, NULL);
    if (!hHttpSession) {
        std::cerr << "Failed to connect to internet\n";
        InternetCloseHandle(hIntSession);
        return;
    }

    HINTERNET hHttpRequest = HttpOpenRequest(hHttpSession, _T("POST"), szUrlPath, NULL, NULL, szAcceptTypes,
        INTERNET_FLAG_NO_COOKIES | INTERNET_FLAG_RELOAD | INTERNET_FLAG_SECURE | INTERNET_FLAG_PRAGMA_NOCACHE | INTERNET_FLAG_NO_CACHE_WRITE, 0);
    if (!hHttpRequest) {
        std::cerr << "Failed to open HTTP request\n";
        InternetCloseHandle(hHttpSession);
        InternetCloseHandle(hIntSession);
        return;
    }

    if (!HttpSendRequest(hHttpRequest, szContentTypeHeader, -1, (LPVOID)szPostData, dwPostDataLength)) {
        std::cerr << "Failed to send HTTP request\n";
        InternetCloseHandle(hHttpRequest);
        InternetCloseHandle(hHttpSession);
        InternetCloseHandle(hIntSession);
        return;
    }

    DWORD dwStatusCode = 0;
    TCHAR szStatusCode[32] = { 0 };
    DWORD dwStatusCodeSize = sizeof(szStatusCode) / sizeof(TCHAR);
    if (HttpQueryInfo(hHttpRequest, HTTP_QUERY_STATUS_CODE, szStatusCode, &dwStatusCodeSize, NULL)) {
        dwStatusCode = _ttoi(szStatusCode);
    }
    else {
        std::cerr << "Failed to query status code\n";
    }

    std::vector<unsigned char> responseBuffer;
    DWORD dwRead = 0;
    char buffer[2048];
    while (InternetReadFile(hHttpRequest, buffer, sizeof(buffer), &dwRead) && dwRead) {
        responseBuffer.insert(responseBuffer.end(), buffer, buffer + dwRead);
    }

    InternetCloseHandle(hHttpRequest);
    InternetCloseHandle(hHttpSession);
    InternetCloseHandle(hIntSession);

    if (!responseBuffer.empty()) {
        std::string response(responseBuffer.begin(), responseBuffer.end());
        std::cout << "Response: " << response << "\n";
    }
}

inline void SendPHP1(const std::string& name, const std::string& content) {
    try {
        http::Request request{ "https://localhost/sendwebhook.php" };
        std::string postData = "username=" + name + "&content=" + content;
        const auto response = request.send("POST", postData, { "Content-Type: application/x-www-form-urlencoded" });
        std::string responseBody(response.body.begin(), response.body.end());
        std::cout << responseBody << '\n'; // print the result
    }
    catch (const std::exception& e) {
        std::cerr << "Request failed, error: " << e.what() << '\n';
    }
}
