#include "imgui_manager.h"

#include "imgui.h"
#include "backends/imgui_impl_win32.h"
#include "backends/imgui_impl_dx11.h"

#include <Windows.h>
#include <d3d11.h>
#include <imgui_impl_win32.cpp>


#pragma comment(lib, "d3d11.lib")
#pragma comment(lib, "dxgi.lib")

namespace
{
    HWND g_hwnd = nullptr;
    ID3D11Device* g_device = nullptr;
    ID3D11DeviceContext* g_context = nullptr;
    IDXGISwapChain* g_swap_chain = nullptr;
    ID3D11RenderTargetView* g_render_target = nullptr;

    bool g_running = false;

    LRESULT WINAPI WndProc(
        HWND hWnd,
        UINT msg,
        WPARAM wParam,
        LPARAM lParam)
    {
        if (ImGui_ImplWin32_WndProcHandler(hWnd, msg, wParam, lParam))
            return true;

        switch (msg)
        {
        case WM_SIZE:
            if (g_device != nullptr && wParam != SIZE_MINIMIZED)
            {
                if (g_render_target)
                {
                    g_render_target->Release();
                    g_render_target = nullptr;
                }

                if (g_swap_chain)
                {
                    g_swap_chain->ResizeBuffers(
                        0,
                        0,
                        0,
                        DXGI_FORMAT_UNKNOWN,
                        0
                    );

                    ID3D11Texture2D* back_buffer = nullptr;

                    if (SUCCEEDED(g_swap_chain->GetBuffer(
                        0,
                        IID_PPV_ARGS(&back_buffer))))
                    {
                        g_device->CreateRenderTargetView(
                            back_buffer,
                            nullptr,
                            &g_render_target
                        );

                        back_buffer->Release();
                    }
                }
            }
            return 0;

        case WM_DESTROY:
            g_running = false;
            PostQuitMessage(0);
            return 0;
        }

        return DefWindowProcW(
            hWnd,
            msg,
            wParam,
            lParam
        );
    }

    bool CreateDeviceD3D(HWND hwnd)
    {
        DXGI_SWAP_CHAIN_DESC sd{};
        sd.BufferCount = 2;
        sd.BufferDesc.Width = 0;
        sd.BufferDesc.Height = 0;
        sd.BufferDesc.Format = DXGI_FORMAT_R8G8B8A8_UNORM;
        sd.BufferDesc.RefreshRate.Numerator = 60;
        sd.BufferDesc.RefreshRate.Denominator = 1;
        sd.Flags = DXGI_SWAP_CHAIN_FLAG_ALLOW_MODE_SWITCH;
        sd.BufferUsage = DXGI_USAGE_RENDER_TARGET_OUTPUT;
        sd.OutputWindow = hwnd;
        sd.SampleDesc.Count = 1;
        sd.SampleDesc.Quality = 0;
        sd.Windowed = TRUE;
        sd.SwapEffect = DXGI_SWAP_EFFECT_DISCARD;

        D3D_FEATURE_LEVEL feature_level;

        const D3D_FEATURE_LEVEL levels[] =
        {
            D3D_FEATURE_LEVEL_11_0,
            D3D_FEATURE_LEVEL_10_0
        };

        HRESULT result = D3D11CreateDeviceAndSwapChain(
            nullptr,
            D3D_DRIVER_TYPE_HARDWARE,
            nullptr,
            0,
            levels,
            ARRAYSIZE(levels),
            D3D11_SDK_VERSION,
            &sd,
            &g_swap_chain,
            &g_device,
            &feature_level,
            &g_context
        );

        if (FAILED(result))
            return false;

        ID3D11Texture2D* back_buffer = nullptr;

        if (FAILED(g_swap_chain->GetBuffer(
            0,
            IID_PPV_ARGS(&back_buffer))))
        {
            return false;
        }

        result = g_device->CreateRenderTargetView(
            back_buffer,
            nullptr,
            &g_render_target
        );

        back_buffer->Release();

        return SUCCEEDED(result);
    }

    void CleanupDeviceD3D()
    {
        if (g_render_target)
        {
            g_render_target->Release();
            g_render_target = nullptr;
        }

        if (g_swap_chain)
        {
            g_swap_chain->Release();
            g_swap_chain = nullptr;
        }

        if (g_context)
        {
            g_context->Release();
            g_context = nullptr;
        }

        if (g_device)
        {
            g_device->Release();
            g_device = nullptr;
        }
    }
}

bool ImGuiManager::Initialize()
{
    WNDCLASSEXW wc{};
    wc.cbSize = sizeof(WNDCLASSEXW);
    wc.style = CS_CLASSDC;
    wc.lpfnWndProc = WndProc;
    wc.hInstance = GetModuleHandleW(nullptr);
    wc.lpszClassName = L"NullProxyImGui";

    RegisterClassExW(&wc);

    g_hwnd = CreateWindowW(
        wc.lpszClassName,
        L"Null Proxy - ImGui",
        WS_OVERLAPPEDWINDOW,
        100,
        100,
        1100,
        700,
        nullptr,
        nullptr,
        wc.hInstance,
        nullptr
    );

    if (!g_hwnd)
        return false;

    if (!CreateDeviceD3D(g_hwnd))
    {
        DestroyWindow(g_hwnd);
        g_hwnd = nullptr;
        return false;
    }

    ShowWindow(g_hwnd, SW_SHOW);
    UpdateWindow(g_hwnd);

    IMGUI_CHECKVERSION();

    ImGui::CreateContext();

    ImGuiIO& io = ImGui::GetIO();
    io.ConfigFlags |= ImGuiConfigFlags_NavEnableKeyboard;

    ImGui::StyleColorsDark();

    if (!ImGui_ImplWin32_Init(g_hwnd))
        return false;

    if (!ImGui_ImplDX11_Init(g_device, g_context))
        return false;

    g_running = true;

    return true;
}

void ImGuiManager::Render()
{
    if (!g_running)
        return;

    MSG msg{};

    while (PeekMessage(
        &msg,
        nullptr,
        0,
        0,
        PM_REMOVE))
    {
        TranslateMessage(&msg);
        DispatchMessage(&msg);

        if (msg.message == WM_QUIT)
        {
            g_running = false;
            return;
        }
    }

    ImGui_ImplDX11_NewFrame();
    ImGui_ImplWin32_NewFrame();

    ImGui::NewFrame();

    ImGui::Begin("Null Proxy");

    ImGui::Text("ImGui basariyla calisiyor!");

    ImGui::Separator();

    if (ImGui::Button("Test Button"))
    {
        MessageBoxW(
            g_hwnd,
            L"ImGui calisiyor!",
            L"Null Proxy",
            MB_OK
        );
    }

    ImGui::End();

    ImGui::Render();

    const float clear_color[] =
    {
        0.08f,
        0.08f,
        0.08f,
        1.0f
    };

    g_context->OMSetRenderTargets(
        1,
        &g_render_target,
        nullptr
    );

    g_context->ClearRenderTargetView(
        g_render_target,
        clear_color
    );

    ImGui_ImplDX11_RenderDrawData(
        ImGui::GetDrawData()
    );

    g_swap_chain->Present(
        1,
        0
    );
}

void ImGuiManager::Shutdown()
{
    g_running = false;

    ImGui_ImplDX11_Shutdown();
    ImGui_ImplWin32_Shutdown();

    ImGui::DestroyContext();

    CleanupDeviceD3D();

    if (g_hwnd)
    {
        DestroyWindow(g_hwnd);
        g_hwnd = nullptr;
    }
}

void ImGuiManager::Start()
{
    if (g_running)
        return;

    Initialize();
}

void ImGuiManager::Stop()
{
    if (!g_running)
        return;

    Shutdown();
}

bool ImGuiManager::IsRunning()
{
    return g_running;
}