#include <iostream>
#include <curl/curl.h>
#include <string>
#include <regex>
#include "json.hpp"



class Login {
public:
    static std::string get_legacy_token(std::string& url, std::string& username,
        std::string& password);
    static std::string extract_token_from_html(std::string& body);
    static size_t WriteCallback(void* contents, size_t size, size_t nmemb, void* userp);
};

size_t Login::WriteCallback(void* contents, size_t size, size_t nmemb, void* userp) {
    ((std::string*)userp)->append((char*)contents, size * nmemb);
    return size * nmemb;
}

std::string Login::get_legacy_token(std::string& url, std::string& username,
    std::string& password) {
    while (true) {
        CURL* curl = curl_easy_init();
        if (!curl) {
            std::cerr << "Failed to initialize CURL" << std::endl;
            return "";
        }

        std::string read_buffer;
        struct curl_slist* headers = nullptr;
        headers = curl_slist_append(headers, "User-Agent: Mozilla/5.0 (X11; Linux x86_64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/126.0.0.0 Safari/537.36");

        curl_easy_setopt(curl, CURLOPT_URL, url.c_str());
        curl_easy_setopt(curl, CURLOPT_HTTPHEADER, headers);
        curl_easy_setopt(curl, CURLOPT_WRITEFUNCTION, WriteCallback);
        curl_easy_setopt(curl, CURLOPT_WRITEDATA, &read_buffer);

        CURLcode res = curl_easy_perform(curl);

        if (res != CURLE_OK) {
            std::cerr << "CURL Error: " << curl_easy_strerror(res) << ", retrying..." << std::endl;
            curl_easy_cleanup(curl);
            continue;
        }

        std::string token = extract_token_from_html(read_buffer);

        if (token.empty()) {
            std::cerr << "Failed to extract token, retrying..." << std::endl;
            curl_easy_cleanup(curl);
            continue;
        }

        // Validate the token
        std::string post_url = "https://login.growtopiagame.com/player/growid/login/validate";
        curl_easy_setopt(curl, CURLOPT_URL, post_url.c_str());
        std::string post_fields = "_token=" + token + "&growId=" + username + "&password=" + password;
        curl_easy_setopt(curl, CURLOPT_POSTFIELDS, post_fields.c_str());

        read_buffer.clear(); // Clear the previous response buffer
        res = curl_easy_perform(curl);

        if (res != CURLE_OK) {
            std::cerr << "Failed to validate token, retrying..." << std::endl;
            curl_easy_cleanup(curl);
            continue;
        }

        nlohmann::json j = nlohmann::json::parse(read_buffer);
        if (j["status"] == "success") {
            std::string auth_token = j["token"];
            std::cout << "Token received: " << auth_token << std::endl;
            curl_easy_cleanup(curl);
            return auth_token;
        }
        else {
            std::cerr << "Token validation failed, retrying..." << std::endl;
            curl_easy_cleanup(curl);
        }
    }
}

std::string Login::extract_token_from_html(std::string& body) {
    const std::regex pattern(R"lit(name="_token"\s+type="hidden"\s+value="([^"]*)")lit");
    auto matches_begin = std::sregex_iterator(body.begin(), body.end(), pattern);
    auto matches_end = std::sregex_iterator();

    for (std::sregex_iterator i = matches_begin; i != matches_end; ++i) {
        const std::smatch& match = *i;
        return match.str(1);
    }
    return "";
}
