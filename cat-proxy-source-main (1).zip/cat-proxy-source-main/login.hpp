#pragma once
#include <string>

class Login {
public:
    // Legacy token almak i�in kullan�lan fonksiyon
    static std::string get_legacy_token(std::string& url, std::string& username,
        std::string& password);

private:
    // HTML'den token ��karmak i�in kullan�lan fonksiyon
    static std::string extract_token_from_html(std::string& body);
};
